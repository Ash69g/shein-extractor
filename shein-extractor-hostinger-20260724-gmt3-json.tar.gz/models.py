"""Backward-compatible imports for domain models."""

from _bootstrap import ensure_src_path

ensure_src_path()

from shein_extractor.domain.models import (  # noqa: E402,F401
    AvailabilityStatus,
    CartExtraction,
    CartShare,
    ExtractedCartItem,
    Price,
    Product,
    Variant,
)

__all__ = [
    "AvailabilityStatus",
    "CartExtraction",
    "CartShare",
    "ExtractedCartItem",
    "Price",
    "Product",
    "Variant",
]
