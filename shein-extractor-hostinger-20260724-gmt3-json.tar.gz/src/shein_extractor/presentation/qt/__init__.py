"""Qt desktop presentation."""

