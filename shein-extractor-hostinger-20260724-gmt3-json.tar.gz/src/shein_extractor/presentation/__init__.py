"""Presentation adapters."""

