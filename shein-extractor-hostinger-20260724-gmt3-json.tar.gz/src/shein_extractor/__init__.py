"""SHEIN cart extraction application."""

