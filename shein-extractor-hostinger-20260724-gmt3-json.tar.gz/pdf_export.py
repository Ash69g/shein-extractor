"""Backward-compatible imports for PDF export."""

from _bootstrap import ensure_src_path

ensure_src_path()

from shein_extractor.infrastructure.pdf import (  # noqa: E402,F401
    PdfExportResult,
    default_pdf_path,
    export_cart_pdf,
    truncate_product_name,
)

__all__ = [
    "PdfExportResult",
    "default_pdf_path",
    "export_cart_pdf",
    "truncate_product_name",
]
